var files_dup =
[
    [ "Lab 4:Mutual Exclusion", "dir_d43297a16da704494a034def0cadb537.html", "dir_d43297a16da704494a034def0cadb537" ]
];